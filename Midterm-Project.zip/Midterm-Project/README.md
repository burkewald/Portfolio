# Midterm Project

This project was to make a webpage with flexbox, scss and a CSS Methodology.
My webpage is and place to find various different information and shop
all different kinds of Vodka around the world.

##Css
SCSS

----------------------

##Css Methodology
BEM

----------------------

##Layout Design Software
  Adobe XD

----------------------

##Text Editor
  Atom

----------------------

##Command Line
  Terminal

----------------------

##Internet Host
  Github

----------------------

##How I Built My Website

  My Css Methodology Consists of BEM.
  
  The stuff coded under the div=topnav is ONLY the mobile nav bar, not the main nav bar. 
  
  The opening function of the hamburger menu is coded in JavaScript.
  
  
  
  
  
 
  
  
